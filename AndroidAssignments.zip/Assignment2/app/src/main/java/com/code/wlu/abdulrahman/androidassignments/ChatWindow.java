package com.code.wlu.abdulrahman.androidassignments;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ChatWindow extends AppCompatActivity {

    ArrayList<String> chatMessages;
    EditText chatInputField;
    Button sendChat;
    ListView chatsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_window);
        chatMessages = (ArrayList<String>) new ArrayList<String>();
        chatsList = (ListView) findViewById(R.id.chatsList);
        chatInputField = (EditText) findViewById(R.id.chatText);
        sendChat = (Button) findViewById(R.id.buttonSend);
        sendChat.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String chatItem = chatInputField.getText().toString();
                chatMessages.add(chatItem);
                ChatAdapter messageAdapter = new ChatAdapter(ChatWindow.this, chatMessages);
                chatsList.setAdapter(messageAdapter);
                messageAdapter.notifyDataSetChanged();

                messageAdapter.getView(chatMessages.size());
                chatInputField.setText("");

                //chatsList = (ListView) messageAdapter.getView(1, , this);
            }
        });

    }

    private class ChatAdapter extends ArrayAdapter<String> {
        public ArrayList<String> mylist;
        //public ChatAdapter(@NonNull Context context, ArrayList<String> thislist) {
        /*public ChatAdapter (Context ctx, ArrayList<String> thislist){
            super(ctx,0);  //, 0, thislist
            mylist =  (ArrayList<String>) thislist;
        }*/

        public ChatAdapter(Context ctx) {
            super(ctx, 0);

        }

        public ChatAdapter(Context ctx, ArrayList<String> xyz) {
            super(ctx, 0);

            mylist = xyz;

            mylist.add("One");
            mylist.add("Two");
            mylist.add("Three");

        }

        public int getCount() {
            if (mylist != null) {
                return mylist.size();
            } else {
                return 0;
            }

        }

        public String getItem(int position) {
            String caught = mylist.get(position).toString();
            caught += "zz";
            return caught;
        }

        public View getView(int position) //, View convertView, ViewGroup parent
        {
            LayoutInflater inflater = ChatWindow.this.getLayoutInflater();
            View result = null;
            if (position % 2 == 0) {
                result = inflater.inflate(R.layout.chat_row_incoming, null);
            } else {
                result = inflater.inflate(R.layout.chat_row_outgoing, null);
            }

            TextView message = (TextView) result.findViewById(R.id.message_text);
            message.setText(getItem(position));

            return result;
        }
    }
}